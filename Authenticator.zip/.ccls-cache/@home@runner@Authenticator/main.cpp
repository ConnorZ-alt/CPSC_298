#include <iostream>
#include <string>
using namespace std;

int main() {
  const char k_cAuthenticatorCodeCharacter1 = 'E';
  const char k_cAuthenticatorCodeCharacter2 = 'C';
  const char k_cAuthenticatorCodeCharacter3 = 'A';

  char cMessageCharCode1 = ' ';
  char cMessageCharCode2 = ' ';
  char cMessageCharCode3 = ' ';

  string AuthenticatorCode = " ";
  string MessageCode = " ";

  int checksum = 0;

  std::cout << "Enter the first character of the message code: " << endl;
  cin >> cMessageCharCode1;
  std::cout << "Enter the second character of the message code: " << endl;
  cin >> cMessageCharCode2;
  std::cout << "Enter the third character of the message code: " << endl;
  cin >> cMessageCharCode3;

  AuthenticatorCode += k_cAuthenticatorCodeCharacter1;
  AuthenticatorCode += k_cAuthenticatorCodeCharacter2;
  AuthenticatorCode += k_cAuthenticatorCodeCharacter3;

  MessageCode += cMessageCharCode1;
  MessageCode += cMessageCharCode2;
  MessageCode += cMessageCharCode3;
  
  std::cout << "Authenticator: " << AuthenticatorCode << endl;
  std::cout << "Message: " << MessageCode << endl;

  if (cMessageCharCode1 == k_cAuthenticatorCodeCharacter1 && cMessageCharCode2 == k_cAuthenticatorCodeCharacter2 && cMessageCharCode3 == k_cAuthenticatorCodeCharacter3){
    std::cout << "The message is valid." << endl;
  } else{
    std::cout << "The message is invalid." << endl;
  }

  if(AuthenticatorCode == MessageCode){
    std::cout << "Concurrence: Message is authentic." << endl;
  
  } else{
    std::cout << "Concurrence: Message is invalid." << endl;
  }

  checksum = (int(cMessageCharCode1) + int(cMessageCharCode2) + int(cMessageCharCode3)) % 7;

  const int k_iValidCodeChecksum = 5;

  if(k_iValidCodeChecksum == checksum){
    std::cout << "Message Code Checksum is valid: " << endl;
} else{
    std::cout << "Message Code Checksum is invalid: " << endl;
  }
  
  cout << "ASCII Values of Message Code Characters: " << int(cMessageCharCode1) << ", " << int(cMessageCharCode2) << 
", " << int(cMessageCharCode3) << endl;
  
  int sum = int(cMessageCharCode1) + int(cMessageCharCode2) + int(cMessageCharCode3);
  
  cout << "Sum of ASCII values for Message Code Characters: " << sum << endl;

  if (cMessageCharCode1 != k_cAuthenticatorCodeCharacter1){cout << "First characters do not match: " << "Message: " << cMessageCharCode1 << "Authenticator: " << k_cAuthenticatorCodeCharacter1 << endl;        
  }
 if (cMessageCharCode2 != k_cAuthenticatorCodeCharacter2) {cout << "Second characters do not match: " << "Message: " << cMessageCharCode2 << "Authenticator: " << k_cAuthenticatorCodeCharacter2 << endl; 
 }
 if (cMessageCharCode3 != k_cAuthenticatorCodeCharacter3){cout << "Third characters do not match: " << "Message: " << cMessageCharCode3 << "Authenticator: " << k_cAuthenticatorCodeCharacter3 << endl;
 }

  if (MessageCode < AuthenticatorCode){
    cout << "Message Code is lexicographically less than Authenticator code (ECA)" << endl;
  } 
  if (MessageCode > AuthenticatorCode){
    cout << "Message Code is lexicographically greater than Authenticator code (ECA)" << endl;
  }
}