#include <cmath>
#include <fstream>
#include <iostream>
using namespace std;

class CentralPolygonalNumbers {
public:
  CentralPolygonalNumbers();
  CentralPolygonalNumbers(int nMax);
  ~CentralPolygonalNumbers();
  void display();
  bool save(std::string strFilename);

private:
  int m_nMax;
  int *mp_iNumbers;
};

CentralPolygonalNumbers::CentralPolygonalNumbers()
    : CentralPolygonalNumbers(0) {}

CentralPolygonalNumbers::CentralPolygonalNumbers(int nMax) {
  mp_iNumbers = new int[nMax + 1];
  for (int n = 0; n <= m_nMax; n++) {
    int p = ((n * n) + n + 2) / 2;
    mp_iNumbers[n] = p;
  }
}

CentralPolygonalNumbers::~CentralPolygonalNumbers() {
  delete[] mp_iNumbers;
  mp_iNumbers = nullptr;
  cout << "Destructor called" << endl;
}

void CentralPolygonalNumbers::display() {
  for (int n = 0; n <= m_nMax; n++) {
    cout << this->mp_iNumbers[n] << " ";
  }
}

bool CentralPolygonalNumbers::save(std::string strFilename) {
  bool success = false;
  ofstream ofsNumbers;
  ofsNumbers.open(strFilename);
  if (ofsNumbers.is_open()) {
    success = true;
  }
  for (int n = 0; n <= m_nMax; n++) {
    ofsNumbers << this->mp_iNumbers[n] << endl;
  }
  ofsNumbers.close();
  return success;
}

int main() {
  CentralPolygonalNumbers cpn(10);
  cpn.display();
  cpn.save("CPN");
  return 0;
}