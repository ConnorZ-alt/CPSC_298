#include <iostream>
using namespace std;

class ElectronicControlUnit {
public:
  ElectronicControlUnit();
  ~ElectronicControlUnit();
  void handleCommand(char cCommand);

private:
  bool m_bActivatedHydraulicJacks; // Button A
  bool m_bActivatedBeltTires;      // Button B
  bool m_bActivatedIRIllumination; // Button E
  void actuateHydraulicJacks();
  void actuateBeltTires();
  void actuateIRIllumination();
};

ElectronicControlUnit::ElectronicControlUnit()
    : m_bActivatedHydraulicJacks(false), m_bActivatedBeltTires(false),
      m_bActivatedIRIllumination(false) {

  this->m_bActivatedHydraulicJacks = false;
  this->m_bActivatedBeltTires = false;
  this->m_bActivatedIRIllumination = false;
  cout << "constructor called" << endl;
}

ElectronicControlUnit::~ElectronicControlUnit() {}
void ElectronicControlUnit::actuateHydraulicJacks() {
  m_bActivatedHydraulicJacks = !m_bActivatedHydraulicJacks;
  if (m_bActivatedHydraulicJacks) {
    cout << "Hydraulic Jacks activated" << endl;
    if (m_bActivatedBeltTires) {
      m_bActivatedBeltTires = false;
      cout << "Belt Tires deactivated" << endl;
    }
  } else {
    cout << "Hydraulic Jacks deactivated" << endl;
  }
}

void ElectronicControlUnit::actuateBeltTires() {
  m_bActivatedBeltTires = !m_bActivatedBeltTires;
  if (m_bActivatedBeltTires) {
    cout << "Belt Tires activated" << endl;
  } else {
    cout << "Belt Tires deactivated" << endl;
  }
}

void ElectronicControlUnit::actuateIRIllumination() {
  m_bActivatedIRIllumination = !m_bActivatedIRIllumination;
  if (m_bActivatedIRIllumination) {
    cout << "IR Illumination activated" << endl;
  } else {
    cout << "IR Illumination deactivated" << endl;
  }
}

void ElectronicControlUnit::handleCommand(char cCommand) {
  switch (cCommand) {
  case 'A':
  case 'a':
    actuateHydraulicJacks();
    break;
  case 'B':
  case 'b':
    actuateBeltTires();
    break;
  case 'E':
  case 'e':
    actuateIRIllumination();
    break;
  default:
    cout << "Invalid Command" << endl;
  }
}

int main() {
  char UserButton = 'X';
  ElectronicControlUnit ecu;
  ecu.handleCommand('a');
  ecu.handleCommand('b');
  cout << "Press X to turn off ignition or enter a steering wheel button (A, "
          "B, or E)"
       << endl;
  cout << "    (A)     " << endl;
  cout << " (F)(G)(B)     " << endl;
  cout << " (E)   (C)     " << endl;
  cout << "    (D)     " << endl;
  cin >> UserButton;

  if (UserButton != 'X') {
    ecu.handleCommand(UserButton);
  } else {
    cout << "Ignition Off" << endl;
  }
}