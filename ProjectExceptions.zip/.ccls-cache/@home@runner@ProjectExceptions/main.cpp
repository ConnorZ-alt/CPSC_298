#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;

unsigned long sigma(unsigned long n){
  unsigned long sum = 0;
  try{
    if(n !=(n>=1)){
      std::runtime_error << "n must be greater than or equal to 1" << std::endl;
    }
    int s = 0;
    for(int i = 0; i <= n; i++){
      s += i;
    }
    if (n !=(sum == (n(n+1)/2))){
      std::runtime_error << "The sum is not correct" << std::endl;
    }
  }    
  catch (std::runtime_error & ex){
    std::cout << "Exception: " << ex.what() << std::endl;
    std::string strMessage = "Precondition n>=1 violated; invalid value for argument n: " + std::to_string(n) + "(Loc: " + __FILE__ + ", " + std::to_string(__LINE__) + ")";
    std::cout << "Cannot compute sum; returning 0" << std::endl;
    sum = 0;
  }
  return sum;
}

int main() {
  int sum = sigma(5);
  std::cout << "Sigma(5) = " << sum << std::endl;
  sum= sigma(0);
  std::cout << "Sigma(0) = " << sum << std::endl;
  
  return 0;
}