#include <iostream>
#include <string>

using namespace std;

class Shape{
  public:
    Shape(double dHeight, double dWidth);
    virtual ~Shape();
    virtual void scale(double dScaleFactor) = 0;
    virtual double area() = 0;
    virtual double perimeter() = 0;
    virtual void displayProperties();

  protected:
    double dHeight;
    double dWidth;
    std::string m_strType;
};

class Rectangle:public Shape{
  public:
    Rectangle(double dHeight, double dWidth);
    virtual ~Rectangle();
    void scale(double dScaleFactor);
    double area();
    double perimeter();
};

class Circle:public Shape{
  public:
    Circle(double dHeight, double dWidth);
    virtual ~Circle();
    void scale(double dScaleFactor);
    double area();
    double perimeter();
};

int main() {
  Rectangle* p_shapeRectangle = new Rectangle(2.0,3.0);
  Circle* p_shapeCircle = new Circle(2.0,2.0);

  Shape* p_shapes[2];

  p_shapes[0] = p_shapeCircle;
  p_shapes[1] = p_shapeRectangle;

  for(int p_shapeCircle = 0; p_shapeCircle < 2; ++p_shapeCircle){
    p_shapeCircle.dispalyProperties();
    p_shapes.scaleByTwo();

    std::cout << "Area: " << p_shapes[i].area() << std::endl;
    std::cout << "Perimeter: " << p_shapes[i].perimeter() << std::endl;
  }
    
  for(int p_shapeRectange = 0; p_shapeRectangle < 2; ++p_shapeRectangle){
    p_shapeRectange.dispalyProperties();
    std::cout << "Properties: " << displayProperties() << std::endl;
    std::cout << "Area: " << p_shapes[i].area() << std::endl;
    std::cout << "Perimeter: " << p_shapes[i].perimeter() << std::endl;
  }
  p_shapes.displayProperties();
  double dArea = p_shapes[1]->area();
}